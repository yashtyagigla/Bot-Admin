# config.py
PAYU_KEY = "your_merchant_key"
PAYU_SALT = "your_merchant_salt"
PAYU_BASE_URL = "https://test.payu.in/_payment"  # Sandbox URL
