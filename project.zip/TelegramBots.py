# # # # # # # # pip install flask requests python-telegram-bot==21.3
# # # # # # # # pip install duckdb fastapi uvicorn httpx
# # # # # # # # TELEGRAM BOT ID 8452377576:AAHdrDpRx6hlqkq5RxrV4tBjC49WWLnfgwk

#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import asyncio
import os
import requests
from dotenv import load_dotenv
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    ApplicationBuilder,
    CallbackQueryHandler,
    ContextTypes,
    MessageHandler,
    filters
)

from real_services import search_countries, get_plans_for_country_and_duration

# ================= ENV =================
load_dotenv()
BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN") or "7898226054:AAHBsfNIryD9IIU1cUYfJsAGDdzeaqRc79s"

USER_STATE = {}

# ================= CURRENCY =================
def usd_to_inr(usd):
    try:
        r = requests.get(
            "https://api.freecurrencyapi.com/v1/latest",
            params={
                "apikey": "fca_live_P9yh7oTJq0xDJfqKVX2ZssVcudSdhDAIHX7q8DEw",
                "base_currency": "USD",
                "currencies": "INR"
            },
            timeout=8
        )
        return round(float(usd) * float(r.json()["data"]["INR"]), 2)
    except Exception:
        return round(float(usd) * 82, 2)

# ================= TEXT HANDLER =================
async def text_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.message.chat.id
    text = update.message.text.strip().lower()

    # 🔄 Restart words
    if text in ["hi", "hello", "hey", "start"]:
        USER_STATE[chat_id] = {"step": "country"}
        await update.message.reply_text("🌍 Type country name:")
        return

    state = USER_STATE.get(chat_id, {})

    # ---------- COUNTRY SEARCH ----------
    if state.get("step") == "country":
        matches = search_countries(text)

        if not matches:
            return  # no spam

        keyboard = [
            [InlineKeyboardButton(c, callback_data=f"country|{c}")]
            for c in matches[:20]
        ]

        await update.message.reply_text(
            "Select country:",
            reply_markup=InlineKeyboardMarkup(keyboard)
        )
        return

    # ---------- DURATION INPUT ----------
    if state.get("step") == "duration":
        if not text.isdigit():
            await update.message.reply_text("❌ Enter duration in days (number only)")
            return

        duration = int(text)
        country = state["country"]

        plans = get_plans_for_country_and_duration(country, duration)

        if not plans:
            await update.message.reply_text("❌ No plans found for this duration")
            return

        msg = f"📦 *{country} – {duration} Day Plans*\n\n"

        for p in plans:
            inr = usd_to_inr(p["usd"])
            msg += (
                f"• {p['data']} | {p['provider']}\n"
                f"  ₹{inr} (${p['usd']})\n"
            )

        await update.message.reply_text(
            msg,
            parse_mode="Markdown",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="back")]
            ])
        )
        return

# ================= CALLBACK =================
async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    chat_id = q.message.chat.id
    data = q.data

    if data.startswith("country|"):
        country = data.split("|", 1)[1]
        USER_STATE[chat_id] = {
            "step": "duration",
            "country": country
        }

        await q.edit_message_text(
            f"📅 Enter duration (days) for *{country}*:",
            parse_mode="Markdown"
        )
        return

    if data == "back":
        USER_STATE[chat_id] = {"step": "country"}
        await q.edit_message_text("🌍 Type country name:")

# ================= MAIN =================
if __name__ == "__main__":
    app = ApplicationBuilder().token(BOT_TOKEN).build()

    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, text_handler))
    app.add_handler(CallbackQueryHandler(button_callback))

    print("🚀 Telegram bot running...")
    asyncio.run(app.run_polling())