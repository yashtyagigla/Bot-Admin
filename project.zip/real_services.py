# # #!/usr/bin/env python3
# # # -*- coding: utf-8 -*-

# # import json
# # import os
# # import requests

# # # ---------------- CONFIG ----------------
# # CACHE_FILE = "data_cache.json"
# # COUNTRY_API = "https://apiesim.connectingit.in/api/country/list"
# # PRODUCT_API = "https://apiesim.connectingit.in/api/product/get-all-product"

# # # ==========================================================
# # # 📦 PACKAGE RANGE LOGIC — with Unlimited pretty label
# # # ==========================================================

# # PACKAGE_RANGES = {
# #     "Minimal": (1, 9.999),   # 1GB to <10GB
# #     "Medium": (10, 19.999),  # 10GB to <20GB
# #     "Heavy": (20, 9999)      # 20GB and above (includes Unlimited)
# # }


# # def get_data_packages():
# #     """Return available package categories."""
# #     return list(PACKAGE_RANGES.keys())


# # def get_data_sizes_by_package(country_name, package_type):
# #     """
# #     Filter data sizes based on package type and include validity in label.
# #     'Heavy' also includes 'Unlimited' (data == 0 or name contains 'Unlimited').
# #     """
# #     plans = get_plans_by_country(country_name)
# #     if not plans:
# #         print(f"[WARN] No plans found for {country_name}")
# #         return []

# #     min_gb, max_gb = PACKAGE_RANGES.get(package_type, (0, 9999))
# #     filtered = set()

# #     for p in plans:
# #         data_val = str(p.get("data", "")).replace("GB", "").strip()
# #         validity = p.get("validity", "N/A")
# #         name = str(p.get("name", "")).lower()

# #         # 🌀 Handle Unlimited
# #         if package_type == "Heavy" and (data_val == "0" or "unlimited" in name):
# #             filtered.add(f"Unlimited Data 🌐 — {validity} Days")
# #             continue

# #         # 🧮 Skip non-numeric data values
# #         if not data_val.replace('.', '', 1).isdigit():
# #             continue

# #         gb = float(data_val)
# #         if min_gb <= gb < max_gb:
# #             filtered.add(f"{int(gb)}GB — {validity} Days")

# #     # Sort, keeping Unlimited last
# #     result = sorted(
# #         list(filtered),
# #         key=lambda x: 9999 if "Unlimited" in x else int(x.split("GB")[0])
# #     )

# #     print(f"[INFO] {len(result)} valid plans found for {country_name} ({package_type}): {result}")
# #     return result

# # # ---------------- FETCH LIVE DATA ----------------
# # def fetch_live_data():
# #     print("[LIVE] Fetching countries and products from API...")

# #     try:
# #         countries_response = requests.get(COUNTRY_API, timeout=30)
# #         products_response = requests.get(PRODUCT_API, timeout=60)

# #         countries = countries_response.json().get("data", [])
# #         products = products_response.json().get("data", [])

# #         cache = {"countries": countries, "products": products}
# #         with open(CACHE_FILE, "w") as f:
# #             json.dump(cache, f, indent=2)

# #         print(f"[CACHE] ✅ Saved {len(countries)} countries and {len(products)} products.")
# #         return cache

# #     except Exception as e:
# #         print(f"[ERROR] Failed to fetch live data: {e}")
# #         return {"countries": [], "products": []}


# # # ---------------- LOAD OR FETCH CACHE ----------------
# # # def load_data():
# # #     if os.path.exists(CACHE_FILE):
# # #         print("[CACHE] Loading data from cache...")
# # #         with open(CACHE_FILE) as f:
# # #             return json.load(f)
# # #     else:
# # #         return fetch_live_data()

# # import time

# # CACHE_FILE = "data_cache.json"
# # CACHE_EXPIRY_HOURS = 24  # Refresh every 24 hours

# # def load_data():
# #     """Load cache if recent; otherwise, fetch new API data."""
# #     if os.path.exists(CACHE_FILE):
# #         try:
# #             file_age_hours = (time.time() - os.path.getmtime(CACHE_FILE)) / 3600
# #             if file_age_hours < CACHE_EXPIRY_HOURS:
# #                 print(f"[CACHE] Loading data from cache (age: {file_age_hours:.2f} hrs)...")
# #                 with open(CACHE_FILE) as f:
# #                     return json.load(f)
# #             else:
# #                 print("[CACHE ⚠️] Cache expired — refreshing live data...")
# #                 return fetch_live_data()
# #         except Exception as e:
# #             print(f"[ERROR] Cache read failed: {e}, refetching...")
# #             return fetch_live_data()
# #     else:
# #         print("[CACHE] No cache file found — fetching fresh data...")
# #         return fetch_live_data()


# # # ---------------- COUNTRY GROUPS ----------------
# # def get_countries_by_group(group, page=1, per_page=10):
# #     """Return filtered unique countries from API or cache by alphabet group, with flags + pagination"""
# #     data = load_data().get("countries", [])
# #     groups = {"A-C": [], "D-F": [], "G-I": [], "J-L": [], "M-O": [], "P-R": [], "S-U": [], "V-Z": []}
# #     seen = set()

# #     # 🏳️ Prepare grouped country lists
# #     for c in data:
# #         name = c.get("countryName", "").strip()
# #         code = c.get("countryCode", "").upper()
# #         if not name or name.lower() in seen:
# #             continue
# #         seen.add(name.lower())

# #         # 🌍 Generate flag emoji dynamically from ISO country code
# #         if len(code) == 2:
# #             flag = chr(127397 + ord(code[0])) + chr(127397 + ord(code[1]))
# #         else:
# #             flag = "🌍"

# #         first = name[:1].upper() if name else "Z"
# #         country_obj = {"name": name, "code": code, "flag": flag}

# #         if "A" <= first <= "C":
# #             groups["A-C"].append(country_obj)
# #         elif "D" <= first <= "F":
# #             groups["D-F"].append(country_obj)
# #         elif "G" <= first <= "I":
# #             groups["G-I"].append(country_obj)
# #         elif "J" <= first <= "L":
# #             groups["J-L"].append(country_obj)
# #         elif "M" <= first <= "O":
# #             groups["M-O"].append(country_obj)
# #         elif "P" <= first <= "R":
# #             groups["P-R"].append(country_obj)
# #         elif "S" <= first <= "U":
# #             groups["S-U"].append(country_obj)
# #         else:
# #             groups["V-Z"].append(country_obj)

# #     # 🧾 Pagination logic
# #     selected_group = groups.get(group, [])
# #     total = len(selected_group)
# #     total_pages = max(1, (total + per_page - 1) // per_page)
# #     start = (page - 1) * per_page
# #     end = start + per_page

# #     paginated = selected_group[start:end]

# #     print(f"[DEBUG] get_countries_by_group({group}, page={page}) → {len(paginated)} shown / {total} total")
# #     return {"countries": paginated, "total_pages": total_pages}

# # def get_country_groups():
# #     """Return alphabetic country groups for selection buttons."""
# #     return ["A-C", "D-F", "G-I", "J-L", "M-O", "P-R", "S-U", "V-Z"]

# # # ---------------- PLAN FILTERING ----------------
# # def get_plans_by_country(country_name):
# #     """Return plans that match a given country name (case-insensitive)"""
# #     data = load_data()
# #     products = data.get("products", [])
# #     matched = []

# #     for p in products:
# #         for c in p.get("countries", []):
# #             if not c:
# #                 continue
# #             cname = c.get("countryName", "").lower()
# #             if country_name.lower() in cname:
# #                 matched.append(p)

# #     print(f"[DEBUG] get_plans_by_country({country_name}) → {len(matched)} plans found")
# #     if matched:
# #         sample_names = [p.get("name") for p in matched[:5]]
# #         print(f"[TRACE] Example plan names: {sample_names}")
# #     return matched


# # # ---------------- DATA SIZE EXTRACTION ----------------
# # def get_available_data_sizes(country_name):
# #     """Extract available unique data sizes (like 1GB, 5GB, etc.)"""
# #     plans = get_plans_by_country(country_name)
# #     sizes = set()

# #     for p in plans:
# #         data_val = str(p.get("data", "")).strip()
# #         if data_val.isdigit():
# #             sizes.add(f"{data_val}GB")

# #     sizes = sorted(list(sizes), key=lambda x: int(x.replace("GB", "")))
# #     return sizes or ["1GB", "3GB", "5GB"]


# # # ---------------- PRICE FETCH ----------------
# # def get_price_for_plan(country_name, data_size):
# #     """Return correct plan price — handles Unlimited and validity."""
# #     print(f"[DEBUG] get_price_for_plan({country_name}, {data_size}) called")
# #     plans = get_plans_by_country(country_name)
# #     if not plans:
# #         print(f"[WARN] No plans found for {country_name}")
# #         return None

# #     # 🧹 Normalize input (remove emojis, dashes, and extra words)
# #     clean_data = (
# #         str(data_size)
# #         .replace("🌐", "")
# #         .replace("—", "-")
# #         .replace("data", "")
# #         .replace("days", "")
# #         .replace("unlimited", "unlimited")
# #         .strip()
# #         .lower()
# #     )

# #     size_value = None
# #     validity_value = None

# #     parts = clean_data.split("-")
# #     if parts:
# #         size_part = parts[0].strip()
# #         if "gb" in size_part:
# #             size_value = size_part.replace("gb", "").strip()
# #         elif "unlimited" in size_part:
# #             size_value = "unlimited"

# #     # extract validity (if present)
# #     if len(parts) > 1:
# #         validity_value = "".join([ch for ch in parts[1] if ch.isdigit()])

# #     # 🔍 Look for matching plan
# #     for p in plans:
# #         plan_name = str(p.get("name", "")).lower()
# #         plan_data = str(p.get("data", "")).strip().lower()
# #         plan_validity = str(p.get("validity", "")).strip().lower()
# #         price = p.get("finalAmount") or p.get("price")

# #         # ✅ Unlimited match (covers both data=0 or “Unlimited”)
# #         if (
# #             size_value == "unlimited"
# #             and ("unlimited" in plan_name or plan_data == "0")
# #         ):
# #             print(f"[MATCH ✅] Found Unlimited plan: {p.get('name')} → ₹{price}")
# #             return price

# #         # ✅ Numeric data + validity match
# #         if size_value and plan_data == size_value:
# #             if not validity_value or validity_value == plan_validity:
# #                 print(f"[MATCH ✅] Found plan: {p.get('name')} → ₹{price}")
# #                 return price

# #     print(f"[WARN] No valid price found for {country_name} {data_size}")
# #     return None
# # # ==========================================================
# # # 📦 PACKAGE RANGE LOGIC — with Unlimited pretty label
# # # ==========================================================

# # PACKAGE_RANGES = {
# #     "Minimal": (1, 4.999),
# #     "Medium": (5, 19.999),
# #     "Heavy": (20, 9999)  # includes Unlimited (0GB)
# # }


# # def get_data_packages():
# #     """Return available package categories."""
# #     return list(PACKAGE_RANGES.keys())


# # # def get_data_sizes_by_package(country_name, package_type):
# # #     """
# # #     Filter data sizes based on package type and include validity in label.
# # #     'Heavy' also includes 'Unlimited' (data == 0) with pretty label.
# # #     """
# # #     plans = get_plans_by_country(country_name)
# # #     if not plans:
# # #         print(f"[WARN] No plans found for {country_name}")
# # #         return []

# # #     min_gb, max_gb = PACKAGE_RANGES.get(package_type, (0, 9999))
# # #     filtered = set()

# # #     for p in plans:
# # #         data_val = str(p.get("data", "")).replace("GB", "").strip()
# # #         validity = p.get("validity", "N/A")

# # #         # 🌀 Handle Unlimited plans (data == 0 or name contains 'Unlimited')
# # #         if package_type == "Heavy" and (data_val == "0" or "unlimited" in str(p.get("name", "")).lower()):
# # #             filtered.add(f"Unlimited Data 🌐 — {validity} Days")
# # #             continue

# # #         if not data_val.replace('.', '', 1).isdigit():
# # #             continue

# # #         gb = float(data_val)
# # #         if min_gb <= gb < max_gb:
# # #             filtered.add(f"{int(gb)}GB — {validity} Days")

# # #     # Sort with Unlimited at the end
# # #     result = sorted(
# # #         list(filtered),
# # #         key=lambda x: 9999 if "Unlimited" in x else int(x.split("GB")[0])
# # #     )

# # #     print(f"[INFO] {len(result)} plans found for {country_name} ({package_type}): {result}")
# # #     return result or ["1GB — 7 Days", "3GB — 15 Days", "5GB — 30 Days"]


# # def get_data_sizes_by_package(country_name, package_type):
# #     """
# #     Filter data sizes based on package type (Minimal, Medium, Heavy)
# #     and include Unlimited plans in Heavy (data == 0 or name contains 'unl'/'unlimited').
# #     If no plans found, show a user-friendly message.
# #     """
# #     plans = get_plans_by_country(country_name)
# #     if not plans:
# #         print(f"[WARN] No plans found for {country_name}")
# #         return [f"⚠️ No plans available for {country_name}. Please try another country."]

# #     min_gb, max_gb = PACKAGE_RANGES.get(package_type, (0, 9999))
# #     filtered = set()

# #     for p in plans:
# #         name = str(p.get("name", "")).lower()
# #         data_val = str(p.get("data", "")).strip().lower()
# #         validity = p.get("validity", "N/A")
# #         price = p.get("finalAmount") or p.get("price")

# #         # 🚫 Skip plans with invalid or zero price
# #         if not price or float(price) <= 0:
# #             continue

# #         # ✅ Detect Unlimited plans (more robust)
# #         if package_type == "Heavy" and (
# #             data_val in ["unlimited", "∞", "0"]
# #             or "unl" in name
# #             or "unlimited" in name
# #         ):
# #             filtered.add(f"Unlimited Data 🌐 — {validity} Days")
# #             continue

# #         # ✅ Detect numeric data sizes
# #         if data_val.replace('.', '', 1).isdigit():
# #             gb = float(data_val)
# #             if min_gb <= gb < max_gb:
# #                 filtered.add(f"{int(gb)}GB — {validity} Days")

# #     if not filtered:
# #         print(f"[INFO] No valid {package_type} plans found for {country_name}")
# #         return [f"⚠️ No {package_type} plans available for {country_name}. Please try another category."]

# #     # ✅ Sort results — Unlimited always last
# #     result = sorted(
# #         list(filtered),
# #         key=lambda x: 9999 if "Unlimited" in x else int(x.split("GB")[0])
# #     )

# #     print(f"[INFO] {len(result)} valid plans found for {country_name} ({package_type}): {result}")
# #     return result

# import requests

# PRODUCTS_API = "http://161.35.242.66:8000/products/db"

# # -----------------------------------------------------
# # Fetch full product list ON EVERY CALL (no cache)
# # -----------------------------------------------------
# def fetch_all_products():
#     try:
#         resp = requests.get(PRODUCTS_API, timeout=10)
#         if resp.status_code == 200:
#             return resp.json().get("data", [])
#     except Exception as e:
#         print("[ERROR] Could not load products API:", e)
#     return []


# # -----------------------------------------------------
# # Return country groups (simple static mapping)
# # -----------------------------------------------------
# def get_country_groups():
#     return ["A-C", "D-F", "G-I", "J-L", "M-O", "P-R", "S-U", "V-Z"]


# # -----------------------------------------------------
# # Filter countries by group
# # -----------------------------------------------------
# def get_countries_by_group(group, page=1):
#     all_products = fetch_all_products()

#     countries = sorted(
#         list({p["countries"][0]["country_name"] for p in all_products})
#     )

#     # group filtering by alphabet
#     start, end = group.split("-")
#     filtered = [c for c in countries if c[0].upper() >= start and c[0].upper() <= end]

#     # pagination
#     per_page = 10
#     total_pages = (len(filtered) + per_page - 1) // per_page
#     start_idx = (page - 1) * per_page
#     page_items = filtered[start_idx:start_idx + per_page]

#     return {
#         "countries": [{"name": c, "flag": "🌍"} for c in page_items],
#         "total_pages": total_pages
#     }


# # -----------------------------------------------------
# # Return package types (simple)
# # -----------------------------------------------------
# def get_data_packages():
#     return ["Minimal", "Medium", "Heavy"]


# # -----------------------------------------------------
# # Get all data sizes for selected country + package
# # -----------------------------------------------------
# def get_data_sizes_by_package(country, package):
#     products = fetch_all_products()

#     # Filter by country name
#     country_plans = [
#         p for p in products
#         if country.lower() in p["name"].lower()
#     ]

#     # Extract readable labels
#     sizes = []
#     for p in country_plans:
#         data = p["data"]
#         days = p["validity"]
#         label = f"{data}GB — {days} Days" if data != "Unlimited" else f"Unlimited — {days} Days"
#         sizes.append(label)

#     return sorted(sizes)


# # -----------------------------------------------------
# # Get actual price for selected plan (USD from API)
# # -----------------------------------------------------
# def get_price_for_plan(country, data_label):
#     products = fetch_all_products()

#     for p in products:
#         if country.lower() in p["name"].lower():
#             days = p["validity"]
#             data = p["data"]

#             api_label = (
#                 f"{data}GB — {days} Days"
#                 if data != "Unlimited"
#                 else f"Unlimited — {days} Days"
#             )

#             if api_label == data_label:
#                 return float(p["price"])  # real USD price

#     print("[WARN] No plan matched in API.")
#     return 0


# import requests

# # ================= CONFIG =================
# PRODUCTS_API = "http://161.35.242.66:8000/products/db"


# # -----------------------------------------------------
# # Fetch products from API (NO CACHE)
# # -----------------------------------------------------
# def fetch_all_products():
#     try:
#         resp = requests.get(PRODUCTS_API, timeout=10)
#         if resp.status_code == 200:
#             return resp.json().get("data", [])
#     except Exception as e:
#         print("[ERROR] Products API failed:", e)
#     return []


# # -----------------------------------------------------
# # Country groups (static)
# # -----------------------------------------------------
# def get_country_groups():
#     return ["A-C", "D-F", "G-I", "J-L", "M-O", "P-R", "S-U", "V-Z"]


# # -----------------------------------------------------
# # Countries by alphabet group + pagination
# # -----------------------------------------------------
# def get_countries_by_group(group, page=1, per_page=10):
#     products = fetch_all_products()

#     country_set = set()
#     for p in products:
#         for c in p.get("countries", []):
#             name = c.get("country_name")
#             if name:
#                 country_set.add(name)

#     countries = sorted(list(country_set))

#     start_char, end_char = group.split("-")
#     filtered = [c for c in countries if start_char <= c[0].upper() <= end_char]

#     total_pages = max(1, (len(filtered) + per_page - 1) // per_page)
#     start = (page - 1) * per_page
#     end = start + per_page

#     page_items = filtered[start:end]

#     return {
#         "countries": [{"name": c, "flag": "🌍"} for c in page_items],
#         "total_pages": total_pages
#     }


# # -----------------------------------------------------
# # Package categories
# # -----------------------------------------------------
# def get_data_packages():
#     return ["Minimal", "Medium", "Heavy"]


# # -----------------------------------------------------
# # Data sizes filtered by package
# # -----------------------------------------------------
# def get_data_sizes_by_package(country, package):
#     products = fetch_all_products()
#     plans = []

#     for p in products:
#         if country.lower() not in p.get("name", "").lower():
#             continue

#         try:
#             data_gb = float(p.get("data"))
#             days = int(p.get("validity"))
#             price = float(p.get("price"))
#         except Exception:
#             continue

#         # ---------- PACKAGE FILTER ----------
#         if package == "Minimal" and data_gb >= 3:
#             continue
#         if package == "Medium" and not (3 <= data_gb < 10):
#             continue
#         if package == "Heavy" and data_gb < 10:
#             continue

#         label = f"{data_gb}GB — {days} Days"
#         plans.append((data_gb, label))

#     # ---------- SORT SMALL → BIG ----------
#     plans.sort(key=lambda x: x[0])

#     result = [label for _, label in plans]

#     print(f"[FILTER] {country} | {package} → {result}")
#     return result or ["⚠️ No plans available"]


# # -----------------------------------------------------
# # Price for selected plan (USD from API)
# # -----------------------------------------------------
# def get_price_for_plan(country, data_label):
#     products = fetch_all_products()

#     # Parse label
#     try:
#         size_part, days_part = data_label.split("—")
#         data_gb = float(size_part.replace("GB", "").strip())
#         days = int(days_part.replace("Days", "").strip())
#     except Exception:
#         print("[ERROR] Invalid label:", data_label)
#         return 0

#     for p in products:
#         if country.lower() not in p.get("name", "").lower():
#             continue

#         try:
#             if float(p["data"]) == data_gb and int(p["validity"]) == days:
#                 print(f"[PRICE MATCH] {data_label} → ${p['price']}")
#                 return float(p["price"])  # USD
#         except Exception:
#             continue

#     print("[WARN] No matching price found")
#     return 0


# import requests

# # ======================================================
# # CONFIG
# # ======================================================
# PRODUCTS_API = "http://161.35.242.66:8000/products/db"

# # Package ranges (GB)
# PACKAGE_RANGES = {
#     "Minimal": (0.1, 1.99),
#     "Medium": (2.0, 9.99),
#     "Heavy": (10.0, 9999),
# }

# # ======================================================
# # FETCH PRODUCTS (LIVE – NO CACHE)
# # ======================================================
# def fetch_all_products():
#     try:
#         resp = requests.get(PRODUCTS_API, timeout=15)
#         if resp.status_code == 200:
#             return resp.json().get("data", [])
#     except Exception as e:
#         print("[ERROR] Product API failed:", e)
#     return []

# # ======================================================
# # COUNTRY GROUPS
# # ======================================================
# def get_country_groups():
#     return ["A-C", "D-F", "G-I", "J-L", "M-O", "P-R", "S-U", "V-Z"]

# # ======================================================
# # COUNTRIES BY GROUP (PAGINATED)
# # ======================================================
# def get_countries_by_group(group, page=1, per_page=10):
#     products = fetch_all_products()

#     countries = sorted({
#         c["country_name"]
#         for p in products
#         for c in p.get("countries", [])
#         if c.get("country_name")
#     })

#     start, end = group.split("-")
#     filtered = [c for c in countries if start <= c[0].upper() <= end]

#     total_pages = max(1, (len(filtered) + per_page - 1) // per_page)
#     start_i = (page - 1) * per_page
#     page_items = filtered[start_i:start_i + per_page]

#     return {
#         "countries": [{"name": c, "flag": "🌍"} for c in page_items],
#         "total_pages": total_pages
#     }

# # ======================================================
# # PACKAGE TYPES
# # ======================================================
# def get_data_packages():
#     return ["Minimal", "Medium", "Heavy"]

# # ======================================================
# # PLANS BY PACKAGE (IMPORTANT PART)
# # 👉 DOES NOT MERGE SAME GB PLANS
# # 👉 EACH PROVIDER = SEPARATE OPTION
# # ======================================================
# def get_data_sizes_by_package(country, package_type):
#     products = fetch_all_products()
#     min_gb, max_gb = PACKAGE_RANGES[package_type]

#     plans = []

#     for p in products:
#         if country.lower() not in p.get("name", "").lower():
#             continue

#         try:
#             gb = float(p.get("data"))
#             price = float(p.get("price"))
#             validity = int(p.get("validity"))
#         except Exception:
#             continue

#         if not (min_gb <= gb <= max_gb):
#             continue

#         provider = p.get("provider", "Unknown")
#         plan_id = p.get("localPlanId")

#         # 🔹 UNIQUE LABEL (provider included)
#         label = f"{gb}GB — {validity} Days | {provider}"

#         plans.append({
#             "label": label,
#             "plan_id": plan_id,
#             "price": price
#         })

#     # 🔃 Sort → GB ↑ then Price ↑
#     plans.sort(key=lambda x: (float(x["label"].split("GB")[0]), x["price"]))

#     print(f"[FILTER] {country} | {package_type} → {[p['label'] for p in plans]}")
#     return plans

# # ======================================================
# # PRICE BY PLAN ID (ONLY SOURCE OF TRUTH)
# # ======================================================
# def get_price_for_plan(plan_id):
#     products = fetch_all_products()
#     for p in products:
#         if str(p.get("localPlanId")) == str(plan_id):
#             price = float(p.get("price"))
#             print(f"[PRICE MATCH] PlanID {plan_id} → ${price}")
#             return price
#     print("[WARN] Price not found for plan_id:", plan_id)
#     return 0.0

# import requests

# PRODUCTS_API = "http://161.35.242.66:8000/products/db"

# def fetch_all_products():
#     try:
#         r = requests.get(PRODUCTS_API, timeout=15)
#         if r.status_code == 200:
#             return r.json().get("data", [])
#     except Exception as e:
#         print("[API ERROR]", e)
#     return []

# # ---------------- COUNTRIES A–Z ----------------
# def get_countries(page=1, per_page=10):
#     products = fetch_all_products()

#     countries = sorted({
#         c["country_name"]
#         for p in products
#         for c in p.get("countries", [])
#         if c.get("country_name")
#     })

#     total_pages = max(1, (len(countries) + per_page - 1) // per_page)
#     start = (page - 1) * per_page
#     end = start + per_page

#     return {
#         "countries": countries[start:end],
#         "total_pages": total_pages
#     }

# # ---------------- SEARCH COUNTRY ----------------
# def search_countries(query):
#     products = fetch_all_products()
#     q = query.lower()

#     return sorted({
#         c["country_name"]
#         for p in products
#         for c in p.get("countries", [])
#         if q in c.get("country_name", "").lower()
#     })

# # ---------------- PLANS WITH PRICE ----------------
# def get_plans_for_country(country):
#     products = fetch_all_products()
#     plans = []

#     for p in products:
#         if country.lower() not in p.get("name", "").lower():
#             continue

#         try:
#             gb = float(p.get("data"))
#             usd = float(p.get("price"))
#             days = int(p.get("validity"))
#             provider = p.get("provider", "Unknown")
#         except:
#             continue

#         plans.append({
#             "label": f"{gb}GB | {provider}",
#             "gb": gb,
#             "usd": usd,
#             "days": days
#         })

#     plans.sort(key=lambda x: x["gb"])
#     return plans

# import requests

# PRODUCTS_API = "http://161.35.242.66:8000/products/db"

# def fetch_all_products():
#     try:
#         r = requests.get(PRODUCTS_API, timeout=15)
#         if r.status_code == 200:
#             return r.json().get("data", [])
#     except Exception as e:
#         print("[API ERROR]", e)
#     return []

# # ---------------- COUNTRIES A–Z ----------------
# def get_countries(page=1, per_page=10):
#     products = fetch_all_products()

#     countries = sorted({
#         c["country_name"]
#         for p in products
#         for c in p.get("countries", [])
#         if c.get("country_name")
#     })

#     total_pages = max(1, (len(countries) + per_page - 1) // per_page)
#     start = (page - 1) * per_page
#     end = start + per_page

#     return {
#         "countries": countries[start:end],
#         "total_pages": total_pages
#     }

# # ---------------- SEARCH COUNTRY ----------------
# def search_countries(query):
#     products = fetch_all_products()
#     q = query.lower()

#     return sorted({
#         c["country_name"]
#         for p in products
#         for c in p.get("countries", [])
#         if q in c.get("country_name", "").lower()
#     })

# # ---------------- PLANS (INCLUDES UNLIMITED) ----------------
# def get_plans_for_country(country, duration):
#     products = fetch_all_products()
#     plans = []

#     for p in products:
#         # ✅ duration mandatory
#         if int(p.get("validity", 0)) != int(duration):
#             continue

#         # ✅ country match INSIDE countries array
#         countries = p.get("countries", [])
#         if not any(
#             country.lower() == c.get("country_name", "").lower()
#             for c in countries
#         ):
#             continue

#         data_val = p.get("data")
#         gb = 9999 if str(data_val).lower() == "unlimited" else float(data_val)

#         plans.append({
#             "provider": p.get("provider", "Unknown"),
#             "gb": gb,
#             "days": int(p.get("validity")),
#             "usd": float(p.get("price"))
#         })

#     # ✅ sort by price (cheap → expensive)
#     plans.sort(key=lambda x: x["usd"])
#     return plans

# import requests

# PRODUCTS_API = "http://161.35.242.66:8000/products/db"

# def fetch_all_products():
#     try:
#         r = requests.get(PRODUCTS_API, timeout=20)
#         if r.status_code == 200:
#             return r.json().get("data", [])
#     except Exception as e:
#         print("[API ERROR]", e)
#     return []

# def get_all_countries():
#     products = fetch_all_products()
#     countries = set()

#     for p in products:
#         for c in p.get("countries", []):
#             if c.get("country_name"):
#                 countries.add(c["country_name"])

#     return sorted(countries)

# def get_plans_for_country_and_duration(country, duration):
#     products = fetch_all_products()
#     plans = []

#     for p in products:
#         if int(p.get("validity", 0)) != duration:
#             continue

#         for c in p.get("countries", []):
#             if c.get("country_name", "").lower() == country.lower():
#                 data_val = p.get("data")
#                 gb = "Unlimited" if str(data_val).lower() == "unlimited" else f"{data_val}GB"

#                 plans.append({
#                     "provider": p.get("provider", "Unknown"),
#                     "data": gb,
#                     "days": p.get("validity"),
#                     "usd": float(p.get("price", 0))
#                 })

#     return plans


# import requests

# PRODUCTS_API = "http://161.35.242.66:8000/products/db"

# def fetch_all_products():
#     try:
#         r = requests.get(PRODUCTS_API, timeout=20)
#         if r.status_code == 200:
#             return r.json().get("data", [])
#     except Exception as e:
#         print("[API ERROR]", e)
#     return []

# # 🔍 Loose country search (typing friendly)
# def search_countries(query):
#     products = fetch_all_products()
#     q = query.lower().strip()

#     if not q:
#         return []

#     results = set()

#     for p in products:
#         for c in p.get("countries", []):
#             name = c.get("country_name", "")
#             if not name:
#                 continue

#             name_l = name.lower()
#             if q in name_l or name_l.startswith(q):
#                 results.add(name)

#     return sorted(results)

# # 📦 Plans by country + duration
# def get_plans_for_country_and_duration(country, duration):
#     products = fetch_all_products()
#     plans = []

#     for p in products:
#         if int(p.get("validity", 0)) != int(duration):
#             continue

#         for c in p.get("countries", []):
#             if c.get("country_name", "").lower() == country.lower():
#                 data_val = p.get("data")

#                 gb = "Unlimited" if str(data_val).lower() == "unlimited" else f"{data_val}GB"

#                 plans.append({
#                     "provider": p.get("provider", "Unknown"),
#                     "data": gb,
#                     "days": p.get("validity"),
#                     "usd": float(p.get("price", 0))
#                 })

#     return plans

import requests

BASE_API = "http://161.35.242.66:8000/products/db"

# ---------------- FETCH COUNTRIES (for search/autocomplete) ----------------
def search_countries(query):
    try:
        r = requests.get(BASE_API, timeout=15)
        products = r.json().get("data", [])
    except Exception:
        return []

    q = query.lower().strip()
    results = set()

    for p in products:
        for c in p.get("countries", []):
            name = c.get("country_name", "")
            if not name:
                continue

            name_l = name.lower()

            # ✅ loose matching (typing mistakes friendly)
            if q in name_l or name_l.startswith(q):
                results.add(name)

    return sorted(results)


# ---------------- FETCH PLANS USING API PARAMS (CORRECT WAY) ----------------
def get_plans_for_country_and_duration(country, duration):
    try:
        r = requests.get(
            BASE_API,
            params={
                "country": country.lower(),
                "duration": int(duration)
            },
            timeout=20
        )

        if r.status_code != 200:
            return []

        products = r.json().get("data", [])
    except Exception as e:
        print("[API ERROR]", e)
        return []

    plans = []

    for p in products:
        data_val = p.get("data")

        # ✅ handle Unlimited properly
        data_label = (
            "Unlimited"
            if str(data_val).lower() == "unlimited"
            else f"{data_val}GB"
        )

        plans.append({
            "provider": p.get("provider", "Unknown"),
            "data": data_label,
            "days": p.get("validity"),
            "usd": float(p.get("price", 0))
        })

    return plans